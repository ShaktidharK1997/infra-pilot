import React, { useState, useEffect, useCallback } from 'react';
import { Bell, XCircle } from 'lucide-react';
import { Alert, AlertDescription } from "./alert";

const NotificationComponent = ({ apiClient, auth }) => {
  const [deployments, setDeployments] = useState([]);
  const [showDeployments, setShowDeployments] = useState(false);
  const [loading, setLoading] = useState(false);

  const fetchDeployments = useCallback(async () => {
    if (!apiClient) return;
    
    setLoading(true);
    try {
      const response = await apiClient.getGet({}, 
        {},
        { 
          headers: { 
            'Authorization': auth.user?.id_token,
            'Content-Type': 'application/json'
          }
        }
      );
      
      if (response.data?.deployments) {
        setDeployments(response.data.deployments);
      }
    } catch (err) {
      console.error('Error fetching deployments:', err);
    } finally {
      setLoading(false);
    }
  }, [apiClient, auth.user?.id_token]);

  useEffect(() => {
    fetchDeployments();
    const interval = setInterval(fetchDeployments, 30000);
    return () => clearInterval(interval);
  }, [fetchDeployments]);

  const toggleDeployments = () => {
    setShowDeployments(!showDeployments);
  };

  return (
    <div className="relative">
      <button
        onClick={toggleDeployments}
        className="relative p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
      >
        <Bell className="w-6 h-6" />
        {deployments.length > 0 && (
          <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full"></span>
        )}
      </button>

      {showDeployments && (
        <div className="absolute right-0 mt-2 w-96 bg-white rounded-lg shadow-xl border z-50">
          <div className="p-4 border-b flex justify-between items-center">
            <h3 className="font-semibold text-gray-700">Recent Deployments</h3>
            <button
              onClick={() => setShowDeployments(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <XCircle className="w-5 h-5" />
            </button>
          </div>

          <div className="max-h-96 overflow-y-auto">
            {loading ? (
              <div className="p-4 text-center">
                <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
              </div>
            ) : deployments.length === 0 ? (
              <div className="p-4 text-center text-gray-500">
                No recent deployments
              </div>
            ) : (
              <div className="p-2 space-y-2">
                {deployments.map((deployment, index) => (
                  <Alert key={index} className="mb-0 bg-blue-50">
                    <div className="font-semibold mb-1">
                      Deployment: {deployment.session_id}
                    </div>
                    <AlertDescription>
                      <div>Resources:</div>
                      <ul className="list-disc pl-5">
                        {deployment.resources.map((resource, rIndex) => (
                          <li key={rIndex}>
                            {resource.type}: {resource.resource_name}
                          </li>
                        ))}
                      </ul>
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(deployment.timestamp).toLocaleString()}
                      </div>
                    </AlertDescription>
                  </Alert>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default NotificationComponent;